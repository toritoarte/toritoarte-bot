CLAVES = [
    "quiero", "me interesa", "encargo", "personalizado",
    "precio", "fecha", "regalo", "comprar", "pagar", "nequi"
]

def interes_real(texto: str) -> bool:
    t = (texto or "").lower()
    return any(k in t for k in CLAVES)
