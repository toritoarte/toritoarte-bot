def publicar(post: dict):
    # MODO PRUEBA: imprime en consola
    print("\n=== PUBLICACIÓN GENERADA ===")
    print(post["texto"])
    print(post["hashtags"])
    print("===========================\n")
