import random

POSTS = [
    "Cada pieza de ToritoArte es única. Hecha a mano en Colombia 🇨🇴",
    "El arte no se repite. Se siente. ✨ ToritoArte",
    "No es solo un objeto. Es una forma de expresar arte en lo cotidiano.",
    "Colores que no pasan desapercibidos. Piezas con intención. 🎨",
]

HASHTAGS = "#ToritoArte #ArteHechoAMano #ArteColombiano #ArtePersonalizado #PopArt"

def generar_post():
    return {
        "texto": random.choice(POSTS),
        "hashtags": HASHTAGS
    }
