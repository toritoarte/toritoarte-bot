import os
from flask import Flask, request
from dotenv import load_dotenv
from filters import interes_real
from whatsapp import enviar_whatsapp_cloud  # Cloud API (FASE 4)

load_dotenv()
app = Flask(__name__)

VERIFY_TOKEN = os.getenv("VERIFY_TOKEN", "toritoarte_verify")


def menu_base():
    return (
        "Hola ✨ Gracias por escribir a ToritoArte.\n"
        "¿Qué te interesa?\n"
        "1) Ver piezas\n"
        "2) Encargo personalizado\n"
        "3) Envíos\n"
        "4) Otra pregunta"
    )


def build_lead_text(user, msg):
    return (
        "🎨 Nuevo interesado – ToritoArte\n\n"
        f"👤 Usuario: {user}\n"
        f"📝 Mensaje: {msg}\n\n"
        "👉 Responder por Instagram/Facebook"
    )


def _safe_get(dct, *keys, default=None):
    cur = dct
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur


def parse_meta_events(data):
    """
    Extrae mensajes de texto reales desde payloads Meta (FB Messenger / IG DM).
    Retorna lista de eventos normalizados.
    """
    events = []

    if not isinstance(data, dict):
        return events

    obj = data.get("object")
    entries = data.get("entry") or []

    if not isinstance(entries, list):
        return events

    for entry in entries:
        if not isinstance(entry, dict):
            continue

        # --- Messenger / IG vía messaging[] ---
        messaging = entry.get("messaging")
        if isinstance(messaging, list):
            for m in messaging:
                if not isinstance(m, dict):
                    continue

                if m.get("delivery") or m.get("read"):
                    continue

                message = m.get("message") or {}
                if message.get("is_echo"):
                    continue

                text = message.get("text")
                if not text:
                    continue

                events.append({
                    "platform": obj or "unknown",
                    "user_id": _safe_get(m, "sender", "id", default="usuario_desconocido"),
                    "page_or_ig_id": _safe_get(m, "recipient", "id"),
                    "text": text.strip(),
                    "raw": m,
                })

        # --- Formato alterno: changes[] ---
        changes = entry.get("changes")
        if isinstance(changes, list):
            for ch in changes:
                value = ch.get("value") or {}
                if not isinstance(value, dict):
                    continue

                text = (
                    _safe_get(value, "message", "text")
                    or value.get("text")
                )

                if not text:
                    continue

                user_id = (
                    _safe_get(value, "from", "id")
                    or _safe_get(value, "sender", "id")
                    or value.get("user_id")
                    or "usuario_desconocido"
                )

                events.append({
                    "platform": obj or "unknown",
                    "user_id": user_id,
                    "page_or_ig_id": entry.get("id"),
                    "text": text.strip(),
                    "raw": ch,
                })

    return events


# --- Verificación webhook Meta ---
@app.get("/webhook")
def verify_webhook():
    mode = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge")

    if mode == "subscribe" and token == VERIFY_TOKEN:
        return challenge, 200

    return "Forbidden", 403


# --- Recepción de mensajes ---
@app.post("/webhook")
def receive_webhook():
    data = request.get_json(silent=True) or {}
    meta_events = parse_meta_events(data)

    # Compatibilidad pruebas manuales
    if not meta_events and "text" in data:
        meta_events = [{
            "platform": "manual",
            "user_id": data.get("user", "usuario_test"),
            "page_or_ig_id": None,
            "text": data.get("text", ""),
            "raw": data,
        }]

    for evt in meta_events:
        text = evt.get("text", "")
        user = evt.get("user_id", "usuario_desconocido")

        print(f"[WEBHOOK] {evt.get('platform')} | user={user} | msg={text[:100]}")

        if interes_real(text):
            token = os.getenv("WHATSAPP_TOKEN")
            if token:
                try:
                    enviar_whatsapp_cloud(build_lead_text(user, text))
                except Exception as e:
                    print("ERROR WhatsApp:", e)
            else:
                print("WhatsApp no configurado. Lead detectado, no enviado.")

    # Meta NO usa esta respuesta; solo confirma recepción
    return {"status": "ok"}, 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)


