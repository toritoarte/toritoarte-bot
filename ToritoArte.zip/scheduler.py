from apscheduler.schedulers.blocking import BlockingScheduler
from content import generar_post
from meta import publicar

sched = BlockingScheduler()

# 2 veces al día: 10:00 y 19:00 hora Colombia
@sched.scheduled_job("cron", hour="10,19", minute="0")
def job():
    post = generar_post()
    publicar(post)

if __name__ == "__main__":
    print("Scheduler activo (publica 2 veces al día). Ctrl+C para detener.")
    sched.start()
